#include <iostream>

#include "tnt.h"
#include "jama_lu.h"

using namespace TNT;

Array2D<double> invert(Array2D<double> A);

 
 
